using Unity.NetCode;
using Unity.Entities;

public struct PlayerSpawnRequest : IRpcCommand
{
}

