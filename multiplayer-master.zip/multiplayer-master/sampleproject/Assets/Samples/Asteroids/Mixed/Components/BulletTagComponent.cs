using Unity.Entities;

[GenerateAuthoringComponent]
public struct BulletTagComponent : IComponentData
{
}
