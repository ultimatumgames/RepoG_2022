using Unity.Entities;

[GenerateAuthoringComponent]
public struct LevelBorder : IComponentData
{
    public int Side;
}
