using Unity.Entities;

[GenerateAuthoringComponent]
public struct AsteroidTagComponentData : IComponentData
{
}
