
namespace Unity.NetCode
{
    static public partial class GhostFieldSubType
    {
		public const int Rotation2D = 1;
		public const int Translation2D = 2;
    }
}