using Unity.Entities;

[GenerateAuthoringComponent]
public struct NetCubeSpawner : IComponentData
{
    public Entity Cube;
}

