## All contributions are subject to the Unity Contribution Agreement

By making a pull request, you are confirming agreement to the terms and conditions of the [Unity Contribution Agreement](https://unity3d.com/legal/licenses/Unity_Contribution_Agreement), including that your Contributions are your original creation and that you have complete right and authority to make your Contributions.
